<?php
/**
 * Plugin Name: LP Custom Student
 * Description: Plugin hiển thị thông báo, shortcode thống kê và custom style LearnPress
 * Version: 1.0
 * Author: Duy
 */

if (!defined('ABSPATH')) exit;

/* =========================
   YÊU CẦU 1: Notification Bar
========================= */
function lp_student_notification_bar() {
    if (!function_exists('learn_press_get_current_user')) return;

    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        $message = "Chào " . $user->display_name . ", bạn đã sẵn sàng bắt đầu bài học hôm nay chưa?";
    } else {
        $message = "Đăng nhập để lưu tiến độ học tập!";
    }

    echo '<div class="lp-notification-bar">' . $message . '</div>';
}
add_action('wp_body_open', 'lp_student_notification_bar');


/* =========================
   YÊU CẦU 2: Shortcode
========================= */
function lp_course_info_shortcode($atts) {
    if (!function_exists('learn_press_get_course')) return "LearnPress chưa cài!";

    $atts = shortcode_atts(array(
        'id' => ''
    ), $atts);

    $course_id = $atts['id'];
    $course = learn_press_get_course($course_id);

    if (!$course) return "Không tìm thấy khóa học!";

    // Số bài học
    $lessons = $course->count_items('lp_lesson');

    // Thời gian khóa học
    $duration = get_post_meta($course_id, '_lp_duration', true);

    // Trạng thái user
    $status = "Chưa đăng nhập";
    if (is_user_logged_in()) {
        $user = learn_press_get_current_user();
        $course_data = $user->get_course_data($course_id);

        if ($course_data) {
            if ($course_data->get_status() == 'completed') {
                $status = "Đã hoàn thành";
            } else {
                $status = "Đã đăng ký";
            }
        } else {
            $status = "Chưa đăng ký";
        }
    }

    ob_start();
    ?>
    <div class="lp-course-info">
        <p><strong>Số bài học:</strong> <?php echo $lessons; ?></p>
        <p><strong>Thời gian:</strong> <?php echo $duration; ?></p>
        <p><strong>Trạng thái:</strong> <?php echo $status; ?></p>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('lp_course_info', 'lp_course_info_shortcode');


/* =========================
   YÊU CẦU 3: Custom CSS
========================= */
function lp_custom_style() {
    wp_enqueue_style(
        'lp-custom-style',
        plugin_dir_url(__FILE__) . 'assets/style.css'
    );
}
add_action('wp_enqueue_scripts', 'lp_custom_style');